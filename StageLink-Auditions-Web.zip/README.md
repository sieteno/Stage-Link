# StageLink Auditions

Prototipo web funcional, responsivo y sin dependencias externas, construido a partir del diseño de Figma y la documentación del proyecto.

## Cómo abrirlo

1. Descomprime el paquete.
2. En la carpeta del proyecto ejecuta `npm start` (no hace falta instalar dependencias).
3. Abre `http://localhost:8080` en un navegador moderno.
4. Elige **Artista** o **Productora / compañía** para recorrer el flujo correspondiente.

También puedes abrir la carpeta `dist` con la extensión **Live Server** de Visual Studio Code o publicarla directamente en cualquier alojamiento estático. Es recomendable servirla por HTTP para que el almacenamiento local se comparta correctamente entre todas las páginas.

## Funciones incluidas

- Selección clara y reversible del tipo de cuenta.
- Feed de audiciones con búsqueda, filtros y convocatorias guardadas.
- Detalle de obra y selección de roles.
- Postulación con materiales del portafolio y seguimiento de estado.
- Portafolio con fotos, videos y documentos, carga con progreso y organización.
- Perfil editable para artistas y productoras.
- Creación guiada de convocatorias en cuatro pasos.
- Panel de candidatos con estado, calificación y notas privadas.
- Notificaciones y descarga de eventos de audición en formato `.ics`.
- Persistencia local mediante `localStorage`.

## Alcance técnico

Esta entrega implementa el front-end completo para demostración. Los datos se guardan en el navegador; los archivos grandes conservan su ficha, no sus bytes. Para producción se requiere conectar un backend para cuentas reales, almacenamiento multimedia, permisos, mensajería y sincronización externa de calendarios.
